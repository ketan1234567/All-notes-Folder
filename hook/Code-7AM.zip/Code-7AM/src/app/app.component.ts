import { Component } from '@angular/core';
import { MsgService } from './msg.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myapp';

  // constructor(private _msg: MsgService) {

  // }

  ngOnInit() {
    //console.log(this._msg.getMessage());

    //var _msg = new MsgService();
    // console.log(_msg.getMessage());
  }
  isShow: boolean = true;
  showHide() {
    this.isShow = !this.isShow;
  }
  
  ngOnDestroy(){
    console.log("AppComponent ngOnDestroy called");
  }

}

