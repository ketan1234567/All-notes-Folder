import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MsgService {

  constructor() { }

  getMessage() {
    return "Hello Sahosoft !!";
  }
}
