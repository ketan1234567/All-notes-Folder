import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {
  @Input() pData: any;
  @Input() names : any;


  constructor(){
    console.log("ChildComponent constructor called");
  }
  ngOnChanges(changes : any){
    console.log("ChildComponent ngOnChanges called");
    //console.log(changes);
  }
  ngOnInit(){
    console.log("ChildComponent ngOnInit called");
  }
  ngDoCheck(){
    console.log("ChildComponent ngDoCheck called");
  }
}
