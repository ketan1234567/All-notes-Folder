import { Injectable } from '@angular/core';
import { Book } from './book';
import { Observable, map, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private Books: Book[] = [
    { id: 100, name: 'Angular 16', price: 2200, description: 'Angular Books' },
    { id: 101, name: 'Angular 15', price: 2300, description: 'Angular Books' },
    { id: 102, name: 'React JS', price: 2400, description: 'React Books' },
    { id: 103, name: 'Node JS', price: 1800, description: 'node Books' },
    { id: 104, name: 'AWS', price: 12000, description: 'AWS Books' },
  ]

  constructor() { }

  getBooks(): Observable<Book[]> {
    return of(this.Books);
  }

  getBookById(id: number): Observable<Book> {
    return this.getBooks().pipe(map(books => books.find(book => book.id == id)));
  }
}
