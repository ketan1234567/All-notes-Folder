import { Component } from '@angular/core';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent {

  // isfinalsubmit(){
  //   return confirm("Are you sure to leave this page -- contact us");
  // }

  canDeactivate(){
    return confirm("Are you sure to leave this page -- contact us");
  }

}
