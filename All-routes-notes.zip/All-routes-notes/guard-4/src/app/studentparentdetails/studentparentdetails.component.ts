import { Component } from '@angular/core';

@Component({
  selector: 'app-studentparentdetails',
  templateUrl: './studentparentdetails.component.html',
  styleUrls: ['./studentparentdetails.component.css']
})
export class StudentparentdetailsComponent {

}
