import { ThemeDirective } from './theme.directive';

describe('ThemeDirective', () => {
  it('should create an instance', () => {
    const directive = new ThemeDirective();
    expect(directive).toBeTruthy();
  });
});
