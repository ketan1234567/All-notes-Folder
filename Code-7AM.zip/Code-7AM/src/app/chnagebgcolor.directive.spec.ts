import { ChnagebgcolorDirective } from './chnagebgcolor.directive';

describe('ChnagebgcolorDirective', () => {
  it('should create an instance', () => {
    const directive = new ChnagebgcolorDirective();
    expect(directive).toBeTruthy();
  });
});
