import { BgcolorDirective } from './bgcolor.directive';

describe('BgcolorDirective', () => {
  it('should create an instance', () => {
    const directive = new BgcolorDirective();
    expect(directive).toBeTruthy();
  });
});
