import { MyngifDirective } from './myngif.directive';

describe('MyngifDirective', () => {
  it('should create an instance', () => {
    const directive = new MyngifDirective();
    expect(directive).toBeTruthy();
  });
});
