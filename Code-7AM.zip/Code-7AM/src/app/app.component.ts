import { Component, ElementRef } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myapp';
  isShow: boolean = true;

  // constructor(private elRef: ElementRef) {

  // }

  ngOnInit() {
    // this.elRef.nativeElement.style.color = 'red';
    // this.elRef.nativeElement.style.fontSize = '50px';
  }

  showHide() {
    this.isShow = !this.isShow;
  }

}

