import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ThemeDirective } from './theme.directive';
import { MyngifDirective } from './myngif.directive';
import { ChnagebgcolorDirective } from './chnagebgcolor.directive';
import { BgcolorDirective } from './bgcolor.directive';

@NgModule({
  declarations: [
    AppComponent,
    ThemeDirective,
    MyngifDirective,
    ChnagebgcolorDirective,
    BgcolorDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
