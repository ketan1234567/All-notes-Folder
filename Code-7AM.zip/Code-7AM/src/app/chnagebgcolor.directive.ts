import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appChangebgcolor]'
})
export class ChnagebgcolorDirective {

  constructor() { }

  // @HostBinding('style.color') myColor : string = 'red';
  // //@HostBinding('style.fontSize') myFontSize : string = '40px';
  // @HostBinding('style.font-size') myFontSize : string = '40px';
  // @HostBinding('style.background-color') bgColor = 'yellow';
  // @HostBinding('style.border') bgBorder = '5px solid black';


  // @HostBinding('class') cls = 'sahosoft';
  // @HostBinding('class') cls = 'sahosoft hcl';


  // @HostListener('click') djoifjlkdf(){
  //   alert('hi');
  // }



  // @HostListener('click') onClick(){
  //   alert('hi');
  // }

  // @HostBinding('class') cls = '';
  // @HostListener('click') onClick() {
  //   this.cls = 'sahosoft hcl';
  // }


  // @HostBinding('style.color') myColor ='black';
  // @HostBinding('style.font-size') myFont ='';

  // @HostListener('mouseover') onMouseOver(){
  //   this.myColor = 'green';
  //   this.myFont = '50px';
  // }
  // @HostListener('mouseleave') onMouseLeave(){
  //   this.myColor = 'black';
  //   this.myFont = '';
  // }



  
  @HostBinding('class') cls = '';
  @HostListener('mouseover') onMouseOver(){
    this.cls = 'sahosoft hcl';
  }
  @HostListener('mouseleave') onMouseLeave(){
    this.cls = '';
  }


}

