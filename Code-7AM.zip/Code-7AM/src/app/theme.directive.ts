import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appTheme]'
})
export class ThemeDirective {

  constructor(private elRef: ElementRef) {
    elRef.nativeElement.style.color = 'green';
    elRef.nativeElement.style.fontSize = '100px';
    elRef.nativeElement.style.backgroundColor = 'yellow';
  }

}
