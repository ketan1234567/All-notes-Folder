import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appMyngif]'
})
export class MyngifDirective {

  constructor(private _templateRef: TemplateRef<any>, private _viewContainerRef: ViewContainerRef) { }

  // @Input() appMyngif: boolean;

  // ngOnInit() {
  //   console.log(this.appMyngif);
  //   if (this.appMyngif) {
  //     this._viewContainerRef.createEmbeddedView(this._templateRef);
  //   } else {
  //     this._viewContainerRef.clear();
  //   }
  // }


  // ngOnChanges() {
  //   //console.log(this.appMyngif);
  //   if (this.appMyngif) {
  //     this._viewContainerRef.createEmbeddedView(this._templateRef);
  //   } else {
  //     this._viewContainerRef.clear();
  //   }
  // }



  @Input() set appMyngif(val: boolean) {
    if (val) {
      this._viewContainerRef.createEmbeddedView(this._templateRef);
    } else {
      this._viewContainerRef.clear();
    }
  }

}
