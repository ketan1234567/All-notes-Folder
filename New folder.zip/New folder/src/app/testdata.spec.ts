import { Testdata } from './testdata';

describe('Testdata', () => {
  it('should create an instance', () => {
    expect(new Testdata()).toBeTruthy();
  });
});
