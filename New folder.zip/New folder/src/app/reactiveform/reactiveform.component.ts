import { Component } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, FormArray } from '@angular/forms';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent {
  // regForm: FormGroup;
  regForm: any;

  constructor(private _fb:FormBuilder) { }
  ngOnInit() {
    // this.regForm = new FormGroup({
    //   id: new FormControl(),
    //   fname: new FormControl(),
    //   lname: new FormControl(),
    //   email: new FormControl(),
    //   mobileno: new FormControl(),
    // })

    // this.regForm =this._fb.group({
    //   id: new FormControl(),
    //   fname: new FormControl(),
    //   lname: new FormControl(),
    //   email: new FormControl(),
    //   mobileno: new FormControl(),
    // })

    // this.regForm =this._fb.group({
    //   id: new FormControl(),
    //   fname: new FormControl(),
    //   lname: new FormControl(),
    //   email: new FormControl(),
    //   mobileno: new FormControl('8588805737'),
    // })

    // this.regForm =this._fb.group({
    //   id: new FormControl(''),
    //   fname: new FormControl(''),
    //   lname: new FormControl(''),
    //   email: new FormControl(''),
    //   mobileno: new FormControl('8588805737'),
    // })

    // this.regForm =this._fb.group({
    //   id: [],
    //   fname: [],
    //   lname: [],
    //   email: [],
    //   mobileno: [],
    // })

    // this.regForm =this._fb.group({
    //   id: [0],
    //   fname: [''],
    //   lname: [''],
    //   email: [''],
    //   mobileno: ['8588805737'],
    // })


    // this.regForm =this._fb.group({
    //   id: [0],
    //   fname: ['',Validators.required],
    //   lname: ['',Validators.required],
    //   email: ['',Validators.required],
    //   mobileno: ['8588805737',Validators.required],
    // })

    // this.regForm =this._fb.group({
    //   id: [0],
    //   fname: ['',[Validators.required,Validators.minLength(5),Validators.maxLength(10)]],
    //   lname: ['',[Validators.required,Validators.minLength(5),Validators.maxLength(10)]],
    //   email: ['',[Validators.required,Validators.email]],
    //   mobileno: ['8588805737',Validators.required],
    // })

    this.regForm =this._fb.group({
      id: [0],
      fname: ['',[Validators.required,Validators.minLength(5),Validators.maxLength(10)]],
      lname: ['',[Validators.required,Validators.minLength(5),Validators.maxLength(10)]],
      email: ['',[Validators.required,Validators.email]],
 
      mobilenos:new FormArray([
        new FormControl()
      ])

    })

    // this.regForm.get('fname').valueChanges.subscribe(firstname=>{
    //   console.log("fname changed : "+ firstname);
    // })
    // this.regForm.get('lname').valueChanges.subscribe(lastname=>{
    //   console.log("lname changed : "+ lastname);
    // })

    // this.regForm.valueChanges.subscribe(formdata=>{
    //   console.log("fname :"+formdata.fname);
    //   console.log('lname:'+formdata.lname);
    // })

    // this.regForm.get('fname').statusChanges.subscribe(fnamestatus=>{
    //   console.log("fname status : "+fnamestatus);
    // })

    // this.regForm.get('lname').statusChanges.subscribe(lnamestatus=>{
    //   console.log("lname status : "+lnamestatus);
    // })

    // this.regForm.statusChanges.subscribe(formdata=>{
    //   console.log("Form Status : "+formdata);
    // })

    // let arr=new FormArray([
    //   new FormControl(),
    //   new FormControl()
    // ])

    // let arr=new FormArray([
    //   new FormControl('Chandan'),
    //   new FormControl('')
    // ])

    let arr=new FormArray([
      new FormControl('Chandan'),
      new FormControl('',Validators.required)
    ])

    console.log(arr.value);
    console.log(arr.valid);

    arr.reset();
    console.log(arr.value);
    console.log(arr.valid);
  }

  register(formdata:FormGroup){
  console.log(formdata.value)
  console.log(formdata.valid);

  // console.log(this.regForm.value);

  // console.log(this.regForm.get('fname').value);
  // console.log(this.regForm.get('lname').value);
  // console.log(this.regForm.get('email').value);
  // console.log(this.regForm.get('mobileno').value);
  }

  reset(){
    // this.regForm.reset();

    this.regForm.reset({
     // fname:'Chandan'
     fname:this.regForm.get('fname').value
    })
  }

  fildata(){
    // this.regForm.setValue({
    //   id:101,
    //   fname:'Sameer',
    //   lname:'Kumar',
    //   email:'Sameer@gmail.com',
    //   mobileno:'654646546'
    // })

    this.regForm.patchValue({
      id:101,
      fname:'Sameer',
      lname:'Kumar',
     // email:'Sameer@gmail.com',
      mobileno:'654646546'
    })
  }

  addmore(){
    this.regForm.get('mobilenos').push(new FormControl());
  }

  deleterow(id:any){
    this.regForm.get('mobilenos').removeAt(id);
  }

}
