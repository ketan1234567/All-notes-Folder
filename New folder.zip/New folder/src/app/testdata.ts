import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Book } from './book';

export class Testdata implements InMemoryDbService {
    createDb() {
        let bookDetails: Book[] = [
            { id: 100, name: 'Angular 16', category: 'Angular Book', year: '2023' },
            { id: 100, name: 'Angular 15', category: 'Angular Book', year: '2023' },
            { id: 100, name: 'React JS', category: 'React Book', year: '2019' },
            { id: 100, name: 'Node JS', category: 'Node Book', year: '2020' },
            { id: 100, name: 'AWS', category: 'AWS Book', year: '2015' },
            { id: 100, name: 'Dot Net Code', category: 'dot net Book', year: '2015' },
        ]
        return {books:bookDetails}
    }
}
