import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private bookURL = '/api/books';

  constructor(private _http: HttpClient) { }

  getAllbooks(): Observable<Book[]> {
    // return this._http.get<Book[]>(this.bookURL);

    return this._http.get<Book[]>(this.bookURL, { responseType: 'json' });

  }

  filterBooks(cat: string, yr: string): Observable<Book[]> {
    let httHeaders = new HttpHeaders()
      .set("Accept", "application/json")

   return this._http.get<Book[]>(this.bookURL + "?category=" + cat + "&year" + yr,{
      headers:httHeaders
    })
  }

  filterBooks1(cat: string, yr: string): Observable<Book[]> {
    let httHeaders = new HttpHeaders()
      .set("Accept", "application/json")

      let httpParams=new HttpParams()
      .set("category",cat)
      .set("year",yr)

   return this._http.get<Book[]>(this.bookURL ,{
      headers:httHeaders,
      params:httpParams
    })
  }

  // getFullResponse():Observable<Book[]>{
  //   return this._http.get<Book[]>(this.bookURL,{
  //     observe:'body'
  //   })
  // }

  getFullResponse():Observable<HttpResponse<Book[]>>{
    return this._http.get<Book[]>(this.bookURL,{
      observe:'response'
    })
  }
}
