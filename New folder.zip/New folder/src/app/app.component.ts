import { Component, HostListener, Input, ViewEncapsulation } from '@angular/core';
import { BookService } from './book.service';
import { Book } from './book';
import { Observable } from 'rxjs';
import { HttpResponse } from '@angular/common/http';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})
export class AppComponent {
  title = 'Welcome to Sahosoft Technologies';
  AllBooks:Book[];

  AllBooks$:Observable<Book[]>;
  searchbooks:Book[];
  searchbooks1:Book[];

  // fullresponse:Book[];
  fullresponse:HttpResponse<Book[]>;

  constructor(private _bookService:BookService){}
  ngOnInit(){
    this.getmyAllBooks();
    this.filterAllBooks("Angular Book","2023");
    this.filterAllBooks1("AWS Book","2015");
    this.getbooksfullresponse();
  }


  getmyAllBooks(){
    this._bookService.getAllbooks().subscribe(res=>{
      this.AllBooks=res;
    })

    this.AllBooks$=this._bookService.getAllbooks();
  }

  filterAllBooks(category,year){
    this._bookService.filterBooks(category,year).subscribe(res=>{
      this.searchbooks=res;
    })
  }

  filterAllBooks1(category,year){
    this._bookService.filterBooks1(category,year).subscribe(res=>{
      this.searchbooks1=res;
    })
  }

  getbooksfullresponse(){
    this._bookService.getFullResponse().subscribe(res=>{
      //debugger;

      if(res.status==200){
        this.fullresponse=res;
      }else{
        console.log("No Data found- some error occured")
      }
     
    })
  }
  
}
