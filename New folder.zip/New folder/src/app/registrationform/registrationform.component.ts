import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registrationform',
  templateUrl: './registrationform.component.html',
  styleUrls: ['./registrationform.component.css']
})
export class RegistrationformComponent {

  userForm: FormGroup;
  constructor(private _fb: FormBuilder) { }

  ngOnInit() {
    // this.userForm=this._fb.group({
    //   fname:['',Validators.required],
    //   lname:['',Validators.required],
    //   houseno:['',Validators.required],
    //   city:['',Validators.required],
    //   pincode:['',Validators.required],
    // })


    this.userForm = this._fb.group({
      fname: ['', Validators.required],
      lname: ['', Validators.required],

      address: this._fb.group({
        houseno: ['', Validators.required],
        city: ['', Validators.required],
        pincode: ['', Validators.required],
      })

    })
  }

  get FnameFC(){
    return this.userForm.get('fname');
  }

  get LnameFC(){
    return this.userForm.get('lname');
  }

  get addressFC(){
    return this.userForm.get('address');
  }

  onFormSubmit() {
    console.log(this.userForm.value);
    console.log(this.userForm.valid);

    let AddressFG=this.addressFC;            //this.userForm.get('address');
    console.log(AddressFG.value);
    console.log(AddressFG.valid);

    console.log("House No :" + AddressFG.get('houseno').value);
    console.log("city :" + AddressFG.get('city').value);
    console.log("pin code :" + AddressFG.get('pincode').value);
  }

}
